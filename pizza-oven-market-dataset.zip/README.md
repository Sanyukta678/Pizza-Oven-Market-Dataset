# Pizza Oven Market Dataset

This repository contains a structured dataset extracted from the public report page "Pizza Oven Market" by Next Move Strategy Consulting (https://www.nextmsc.com/report/pizza-oven-market-se3642).

## Contents
- `dataset.csv` — a one‑row CSV capturing market size, CAGR, segmentation, and key players.
- `metadata.json` — metadata describing field structure and provenance.
- `README.md` — this file.

## About the Source
All market figures, segmentation details, and key players were gathered from the publicly accessible report summary page. For complete datasets, charts, or full PDF access, please refer to the original publisher. This dataset is intended strictly for educational and prototype analytical use.

## Fields
See `metadata.json` for detailed descriptions. Main fields include:
- Market_Size_2024_USD_billion, Market_Size_2025_USD_billion, Market_Projection_2030_USD_billion — reported global valuations.
- CAGR_2025_2030_percent — projected compound annual growth rate.
- Segments — the segmentation categories: Type, Application, Distribution Channel.
- Key_Players — manufacturer and technology providers listed in the report.

## License & Attribution
This dataset is a derived summary of publicly visible information and is provided for demonstration purposes. Attribution to Next Move Strategy Consulting is required for any reuse.

## Reference README Style
Structured following the format used in:
https://github.com/Sanyukta678/immunoglobulin-market-dataset/blob/main/README.md
